//
//  ViewController.swift
//  Temperature
//
//  Created by Estelle Susanto on 8/29/16.
//  Copyright © 2016 Estelle Susanto. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var sliderLabel: UILabel!
    
    @IBAction func sliderChanged(_ sender: UISlider) {
        /*
        The sender's value, i.e., the slider's value is a floating point value.
        Floating point values are always truncated when used to initialize a new integer.
        Therefore, we add 0.5 to round the value to the nearrest integer value
         */
        let sliderIntValue = Int(sender.value+0.5) //conversion from float to integer
        
        /*
        Slider's integer value is converted into a String value.
        The string value is assigned to be the slider's label text.
        */
        
         sliderLabel.text = String(sliderIntValue) + "℉" //conversion from integer to string
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

